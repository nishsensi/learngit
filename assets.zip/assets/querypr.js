if( typeof( SiebelAppFacade.querypr ) === "undefined" ){
    SiebelJS.Namespace( "SiebelAppFacade.querypr" );
    define("siebel/custom/querypr", ["siebel/jqgridrenderer"], function () {
        SiebelAppFacade.querypr = ( function(){
            function querypr( pm ){
                SiebelAppFacade.querypr.superclass.constructor.call( this, pm );
            }
            SiebelJS.Extend( querypr, SiebelAppFacade.JQGridRenderer );
			querypr.prototype.Init = function () {
            SiebelAppFacade.querypr.superclass.Init.call(this);
            };
			querypr.prototype.ShowUI = function(){
                SiebelAppFacade.querypr.superclass.ShowUI.call( this );
				var currbwidth = $(".ui-jqgrid-bdiv").width();
				 var btabwidth = currbwidth - 40;
				 var currhwidth = $(".ui-state-default.ui-jqgrid-hdiv").width();
				 var htabwidth = currhwidth - 40;
				 var currheight = $(".ui-jqgrid-bdiv").height();
				 $(".ui-state-default.ui-jqgrid-hdiv").css("width",htabwidth);
				 $(".ui-state-default.ui-jqgrid-hdiv").css("float","left");
				 $(".ui-jqgrid-bdiv").css("width",btabwidth);
				 $(".ui-jqgrid-bdiv").css("float","left");   // above lines creates 40px room to accomodate our scrollbar
				
				$('.ui-jqgrid-bdiv').after('<div class="navsetcls" style="backgroundColor:rgb(241, 241, 241)"><div id="sliderdiv"></div><a href="Javascript:void(0)" class="prevset"><img title="up" id="prevset" style="display:block;position:relative" src="images/prevset.png"/></a><a href="Javascript:void(0)" class="slider"><img title="slider" id="slider" style="display:block;position:relative" src="images/slider.png"/></a><a href="Javascript:void(0)" class="nextset"><img title="down" id="nextset" style="display:block;position:relative" src="images/nextset.png"/></a></div>');	// add the html for scrollbar, images and slider, images size is 18x18 and slider is 18x66

				$(".navsetcls").css("float","left");
				$(".navsetcls").css("width","18");
				$(".navsetcls").css("background-color","rgb(241, 241, 241)");
				$(".navsetcls").css("height",currheight);
				$("#slider").css("top",0);
				$("#nextset").css("top",currheight-102); // set the properties to images and scroll section. 102 here is slider height (66) + navigation images height (18 + 18)
				var pm = this.GetPM();
				
				if(!pm.ExecuteMethod("CanInvokeMethod", "GotoPreviousSet")){
					$("#slider").css("top",0);
				}
				else if(!pm.ExecuteMethod("CanInvokeMethod", "GotoNextSet")){
					$("#slider").css("top",currheight-102);
				}
				else{
					$("#slider").css("top",(currheight-102)/2);
				} // show slider according to present record selection
            };	
			querypr.prototype.BindEvents = function(){
				SiebelAppFacade.querypr.superclass.BindEvents.call( this );	
				var pm = this.GetPM();
				var currheight = $(".ui-jqgrid-bdiv").height();
				var int;
				$("a.nextset").mousedown(function() {
					int = setInterval(performWhileMouseDownNextSet, 1000);
				}).mouseup(function() {
				  clearInterval(int);  
				});
				$("a.prevset").mousedown(function() {
					int = setInterval(performWhileMouseDownPrevSet, 1000);
				}).mouseup(function() {
				  clearInterval(int);  
				}); // click and hold the navigation images, every 1000 milliseconds, nav to record set
				function performWhileMouseDownNextSet() {
					if(pm.ExecuteMethod("CanInvokeMethod", "GotoNextSet")){
								pm.ExecuteMethod("InvokeMethod","GotoNextSet",null,false);
								if(!pm.ExecuteMethod("CanInvokeMethod", "GotoNextSet")){
									$("#slider").css("top",currheight-102);
								}
								else{
									$("#slider").css("top",(currheight-102)/2);
								}
							}
				} // function to check and move to next record set and move the slider image
				function performWhileMouseDownPrevSet() {
					if(pm.ExecuteMethod("CanInvokeMethod", "GotoPreviousSet")){
								pm.ExecuteMethod("InvokeMethod","GotoPreviousSet",null,false);
								if(!pm.ExecuteMethod("CanInvokeMethod", "GotoPreviousSet")){
									$("#slider").css("top",0);
								}
								else{
									$("#slider").css("top",(currheight-102)/2);
								}
							}
				} // function to check and move to previous set and move the slider image
				$('div.navsetcls').mousedown(function (event){
					var x = event.clientX;
					var y = event.clientY;
					var upY = $("#prevset").offset();
					var downY = $("#nextset").offset();
					var sl = $("#slider").offset();
					sl = sl.top;
					if (sl > y && y > upY.top + 18)
					{
							performWhileMouseDownPrevSet();
					}
					else if (sl<y && downY.top > y)
					{
							performWhileMouseDownNextSet();
					}
				}); // click on slider to navigate to prev or next record sets
				$('a.nextset').click(function(){
							performWhileMouseDownNextSet();
						});
				$('a.prevset').click(function(){
							performWhileMouseDownPrevSet();
						}); // click on up and down images to navigate
					
        };
			querypr.prototype.resize = function(){
				SiebelAppFacade.querypr.superclass.resize.call( this );
			}
            return querypr;
        } ());
        return "SiebelAppFacade.querypr";
    });
}